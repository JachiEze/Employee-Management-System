import React from "react";

const x = "MetaHR";

const Test = () => {
    return (
    <h1>Hello, this is {x}!</h1>
    )
}

export default Test;