﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common.Constants
{
    public static class Folders
    {
        public static string ProfilePictures = "profile-pictures";
        public static string Cvs = "cvs";
    }
}
